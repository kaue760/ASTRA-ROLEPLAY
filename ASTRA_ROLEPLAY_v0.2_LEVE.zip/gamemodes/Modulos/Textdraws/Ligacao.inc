	PAppLigacao[playerid][0] = CreatePlayerTextDraw(playerid, 182.000000, 234.000000, "123456");
	PlayerTextDrawFont(playerid, PAppLigacao[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, PAppLigacao[playerid][0], 0.254166, 1.200000);
	PlayerTextDrawTextSize(playerid, PAppLigacao[playerid][0], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, PAppLigacao[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, PAppLigacao[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, PAppLigacao[playerid][0], 3);
	PlayerTextDrawColor(playerid, PAppLigacao[playerid][0], 707472639);
	PlayerTextDrawBackgroundColor(playerid, PAppLigacao[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, PAppLigacao[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, PAppLigacao[playerid][0], 0);
	PlayerTextDrawSetProportional(playerid, PAppLigacao[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, PAppLigacao[playerid][0], 0);

