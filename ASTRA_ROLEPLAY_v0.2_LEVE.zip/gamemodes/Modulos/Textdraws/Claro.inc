    //creditos
	ClaroAppP[playerid][0] = CreatePlayerTextDraw(playerid, 134.000000, 257.000000, "Creditos:_1000");
	PlayerTextDrawFont(playerid, ClaroAppP[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, ClaroAppP[playerid][0], 0.166666, 0.850000);
	PlayerTextDrawTextSize(playerid, ClaroAppP[playerid][0], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, ClaroAppP[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, ClaroAppP[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, ClaroAppP[playerid][0], 1);
	PlayerTextDrawColor(playerid, ClaroAppP[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, ClaroAppP[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, ClaroAppP[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, ClaroAppP[playerid][0], 0);
	PlayerTextDrawSetProportional(playerid, ClaroAppP[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, ClaroAppP[playerid][0], 0);

