	AbordagemP[playerid][0] = CreatePlayerTextDraw(playerid, 431.000000, 251.000000, "32456");
	PlayerTextDrawFont(playerid, AbordagemP[playerid][0], 0);
	PlayerTextDrawLetterSize(playerid, AbordagemP[playerid][0], 0.295832, 1.200000);
	PlayerTextDrawTextSize(playerid, AbordagemP[playerid][0], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, AbordagemP[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, AbordagemP[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, AbordagemP[playerid][0], 2);
	PlayerTextDrawColor(playerid, AbordagemP[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, AbordagemP[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, AbordagemP[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, AbordagemP[playerid][0], 0);
	PlayerTextDrawSetProportional(playerid, AbordagemP[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, AbordagemP[playerid][0], 0);

