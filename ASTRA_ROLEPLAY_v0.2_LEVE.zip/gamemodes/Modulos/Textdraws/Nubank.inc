	//CELULAR
	PAppNubank[playerid][0] = CreatePlayerTextDraw(playerid, 115.000000, 217.000000, "Ola,_luis_bolado");
	PlayerTextDrawFont(playerid, PAppNubank[playerid][0], 1);
	PlayerTextDrawLetterSize(playerid, PAppNubank[playerid][0], 0.129166, 0.899999);
	PlayerTextDrawTextSize(playerid, PAppNubank[playerid][0], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, PAppNubank[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, PAppNubank[playerid][0], 0);
	PlayerTextDrawAlignment(playerid, PAppNubank[playerid][0], 1);
	PlayerTextDrawColor(playerid, PAppNubank[playerid][0], -1);
	PlayerTextDrawBackgroundColor(playerid, PAppNubank[playerid][0], 255);
	PlayerTextDrawBoxColor(playerid, PAppNubank[playerid][0], 50);
	PlayerTextDrawUseBox(playerid, PAppNubank[playerid][0], 0);
	PlayerTextDrawSetProportional(playerid, PAppNubank[playerid][0], 1);
	PlayerTextDrawSetSelectable(playerid, PAppNubank[playerid][0], 0);

	PAppNubank[playerid][1] = CreatePlayerTextDraw(playerid, 115.000000, 258.000000, "R$_1.357.97");
	PlayerTextDrawFont(playerid, PAppNubank[playerid][1], 1);
	PlayerTextDrawLetterSize(playerid, PAppNubank[playerid][1], 0.129166, 0.899999);
	PlayerTextDrawTextSize(playerid, PAppNubank[playerid][1], 400.000000, 17.000000);
	PlayerTextDrawSetOutline(playerid, PAppNubank[playerid][1], 0);
	PlayerTextDrawSetShadow(playerid, PAppNubank[playerid][1], 0);
	PlayerTextDrawAlignment(playerid, PAppNubank[playerid][1], 1);
	PlayerTextDrawColor(playerid, PAppNubank[playerid][1], 1296911871);
	PlayerTextDrawBackgroundColor(playerid, PAppNubank[playerid][1], 255);
	PlayerTextDrawBoxColor(playerid, PAppNubank[playerid][1], 50);
	PlayerTextDrawUseBox(playerid, PAppNubank[playerid][1], 0);
	PlayerTextDrawSetProportional(playerid, PAppNubank[playerid][1], 1);
	PlayerTextDrawSetSelectable(playerid, PAppNubank[playerid][1], 0);

