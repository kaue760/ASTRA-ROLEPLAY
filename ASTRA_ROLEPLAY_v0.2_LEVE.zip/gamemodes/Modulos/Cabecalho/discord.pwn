//_-_-_-_-_-DISCORD-CONNECTOR-_-_-_-_-_//
#define DCMD_PREFIX '!' //Prefixo bot (OBS: 1 caractere somente)
#define PREFIX_MSG  "!" //Prefix q aparece na msg
#include  <discord-connector>
#include  <discord-cmd>
new DCC_Channel:logsvipdc;
new DCC_Channel:logsbandc;
new DCC_Channel:logscadeiadc;
new DCC_Channel:logsorgsdc;
new DCC_Channel:logscoinsdc;
new DCC_Channel:logsinf;
new DCC_Channel:logsavs;
new DCC_Channel:logsturnosdc;
new DCC_Channel:logsleveisdc;
new DCC_Channel:logsverificacaodc;
new DCC_Channel:logsreinicio;
new DCC_Channel:logseventos;
//new DCC_Channel:logswldc;
new DCC_Channel:logsbanavisodc;
new DCC_Channel:batepapoaviso;
new DCC_Channel:logscadeiaavisodc;
new DCC_Channel:logsTerritoriosaviso;
new DCC_Channel:logsEventos;
new DCC_Channel:logsCofrePref;
new DCC_Channel:logsTranparencia;
new DCC_Channel:logsEleicoes;
//new DCC_Channel:logsverificacaoavisodc;
//new DCC_Channel:logswlavisodc;
new DCC_Channel:logsavisosdc;
new DCC_Channel:cmdliberacao;
//new DCC_Channel:cmdwhitelist;
new DCC_Channel:cmdban;
new DCC_Channel:cmdcadeia;
new DCC_Channel:cmdvlc;
new DCC_Channel:cmdaviso;
new DCC_Channel:cmdavisos;
new DCC_Channel:cmdreiniciar;
 
//Cor do seu Embed
//Veja mais cores em: https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
#define COR_EMBED   15964170

//Altere para o link para onde quem clicar sera direcionado.
#define URL_EMBED   ""

//Altere o Status do Bot
#define STATUS_BOT Jogando Dragon Roleplay

//_-_-_-_-_-DISCORD-VERIFICACAO-_-_-_-_-_//
#define DISCORD_ID			"1316786590818893937"   // Discord Server ID
#define DISCORD_CHANNEL 	"1389482938269433947"  // Discord channel ID
#define ROLE_ID				"1366808415074127903"  // Discord Role ID 
#define FEMALE 				"1366808415074127903"  // Cargo de mulher
#define MALE 				"1366808415074127903"  // Cargo de homen

new DCC_Channel:discord_channel;
new DCC_Guild:discord_guild;
new DCC_Role:discord_role;
new DCC_Role:male_role;
new DCC_Role:female_role;

IsDiscordUserVerified(DCC_User:user, &bool:has_role) 
{
    DCC_HasGuildMemberRole(discord_guild, user, discord_role, has_role);
}
