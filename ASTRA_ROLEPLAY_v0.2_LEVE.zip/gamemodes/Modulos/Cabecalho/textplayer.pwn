//_-_-_-_-_-CARREGAMENTO-_-_-_-_-_//
new PlayerText:TelaCarregamentoP[MAX_PLAYERS][2] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-EQUIPAR POLICIA-_-_-_-_-_//
new PlayerText:EquipPoliceP[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-ABRINDO CADEADO-_-_-_-_-_//
new PlayerText:JackCarP[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-LEITERO-_-_-_-_-_//
new PlayerText:LeiteroTDP[MAX_PLAYERS][2] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-LOGIN-_-_-_-_-_//
new PlayerText:Log_LifeP[MAX_PLAYERS][2] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-REGISTRO-_-_-_-_-_//
new PlayerText:Reg_LifeP[MAX_PLAYERS][5] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-ABORDAGEM-_-_-_-_-_//
new PlayerText:AbordagemP[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-CRAFT-_-_-_-_-_//
new PlayerText:CraftPTD[MAX_PLAYERS][16] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-TELA PRETA-_-_-_-_-_//
new PlayerText:TextTelaPreta[MAX_PLAYERS] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-BAU-_-_-_-_-_//
new PlayerText:BauCasa[MAX_PLAYERS][71] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-GARAGEM-_-_-_-_-_//
new PlayerText:GaragemTDP[MAX_PLAYERS][23] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-LOJA DE ACC-_-_-_-_-_//
new PlayerText:LojaDeAccTxt[MAX_PLAYERS][12] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-COMMPROVANTE-_-_-_-_-_//
new PlayerText:PTDComprovante[MAX_PLAYERS][7] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-MENSAGEM TELA-_-_-_-_-_//
new PlayerText:MensagemTela[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-CAIXA ELETRONICO-_-_-_-_-_//
new PlayerText:PEletronicoLife[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-CONVITES-_-_-_-_-_//
new PlayerText:americaauto[MAX_PLAYERS][26] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-BARRAQUINHAS-_-_-_-_-_//
new PlayerText:TextBarraquinha[MAX_PLAYERS][31] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-TESOURO-_-_-_-_-_//
new PlayerText:TesouroTextPlayer[MAX_PLAYERS][18] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-LOJA DE SKINS-_-_-_-_-_//
new PlayerText:TextSkinMenuP[MAX_PLAYERS][3] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-EDITAR PORTAO-_-_-_-_-_//
new PlayerText:PTDEditorObjetos[MAX_PLAYERS][2] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-BARRA DE CARREGAMENTO-_-_-_-_-_//
new PlayerText:TextCarregamento[MAX_PLAYERS][3];

//_-_-_-_-_-FABRICAR ARMAS-_-_-_-_-_//
new PlayerText:FabricaDeArmas[MAX_PLAYERS][19] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-RADIO-_-_-_-_-_//
new PlayerText:RadinhoTextP[MAX_PLAYERS][1] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-COMPRAR CONCE-_-_-_-_-_//
new PlayerText:TextConceP[MAX_PLAYERS][3] = {PlayerText:INVALID_TEXT_DRAW, ...};

//_-_-_-_-_-VELOCIMETRO-_-_-_-_-_//
new PlayerText:VelocimetroTP[MAX_PLAYERS][3] = {PlayerText:INVALID_TEXT_DRAW, ...};





stock CriarVelocimetro(playerid)
{
    //_-_-_-_-_-VELOCIMETRO-_-_-_-_-_//
    VelocimetroTP[playerid][0] = CreatePlayerTextDraw(playerid, 320.000000, 408.000000, "199");
    PlayerTextDrawFont(playerid, VelocimetroTP[playerid][0], 2);
    PlayerTextDrawLetterSize(playerid, VelocimetroTP[playerid][0], 0.295833, 1.900000);
    PlayerTextDrawTextSize(playerid, VelocimetroTP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, VelocimetroTP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, VelocimetroTP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, VelocimetroTP[playerid][0], 2);
    PlayerTextDrawColor(playerid, VelocimetroTP[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, VelocimetroTP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, VelocimetroTP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, VelocimetroTP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, VelocimetroTP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, VelocimetroTP[playerid][0], 0);

    VelocimetroTP[playerid][1] = CreatePlayerTextDraw(playerid, 279.000000, 415.000000, "100");
    PlayerTextDrawFont(playerid, VelocimetroTP[playerid][1], 2);
    PlayerTextDrawLetterSize(playerid, VelocimetroTP[playerid][1], 0.141666, 0.950000);
    PlayerTextDrawTextSize(playerid, VelocimetroTP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, VelocimetroTP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, VelocimetroTP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, VelocimetroTP[playerid][1], 2);
    PlayerTextDrawColor(playerid, VelocimetroTP[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, VelocimetroTP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, VelocimetroTP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, VelocimetroTP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, VelocimetroTP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, VelocimetroTP[playerid][1], 0);

    VelocimetroTP[playerid][2] = CreatePlayerTextDraw(playerid, 372.000000, 415.000000, "100");
    PlayerTextDrawFont(playerid, VelocimetroTP[playerid][2], 2);
    PlayerTextDrawLetterSize(playerid, VelocimetroTP[playerid][2], 0.141666, 0.950000);
    PlayerTextDrawTextSize(playerid, VelocimetroTP[playerid][2], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, VelocimetroTP[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, VelocimetroTP[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, VelocimetroTP[playerid][2], 2);
    PlayerTextDrawColor(playerid, VelocimetroTP[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, VelocimetroTP[playerid][2], 255);
    PlayerTextDrawBoxColor(playerid, VelocimetroTP[playerid][2], 50);
    PlayerTextDrawUseBox(playerid, VelocimetroTP[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, VelocimetroTP[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, VelocimetroTP[playerid][2], 0);
    return 1;
}

stock CriarConce(playerid)
{
    //_-_-_-_-_-MENU CONCE-_-_-_-_-_//
    TextConceP[playerid][0] = CreatePlayerTextDraw(playerid, 270.000000, 378.000000, "189_KM/H");
    PlayerTextDrawFont(playerid, TextConceP[playerid][0], 2);
    PlayerTextDrawLetterSize(playerid, TextConceP[playerid][0], 0.150000, 1.099999);
    PlayerTextDrawTextSize(playerid, TextConceP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TextConceP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, TextConceP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, TextConceP[playerid][0], 2);
    PlayerTextDrawColor(playerid, TextConceP[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, TextConceP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, TextConceP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, TextConceP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, TextConceP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, TextConceP[playerid][0], 0);

    TextConceP[playerid][1] = CreatePlayerTextDraw(playerid, 369.000000, 378.000000, "$1000000");
    PlayerTextDrawFont(playerid, TextConceP[playerid][1], 2);
    PlayerTextDrawLetterSize(playerid, TextConceP[playerid][1], 0.150000, 1.099999);
    PlayerTextDrawTextSize(playerid, TextConceP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TextConceP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, TextConceP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, TextConceP[playerid][1], 2);
    PlayerTextDrawColor(playerid, TextConceP[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, TextConceP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, TextConceP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, TextConceP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, TextConceP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, TextConceP[playerid][1], 0);

    TextConceP[playerid][2] = CreatePlayerTextDraw(playerid, 320.000000, 378.000000, "CORVETTE");
    PlayerTextDrawFont(playerid, TextConceP[playerid][2], 2);
    PlayerTextDrawLetterSize(playerid, TextConceP[playerid][2], 0.150000, 1.099999);
    PlayerTextDrawTextSize(playerid, TextConceP[playerid][2], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TextConceP[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, TextConceP[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, TextConceP[playerid][2], 2);
    PlayerTextDrawColor(playerid, TextConceP[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, TextConceP[playerid][2], 255);
    PlayerTextDrawBoxColor(playerid, TextConceP[playerid][2], 50);
    PlayerTextDrawUseBox(playerid, TextConceP[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, TextConceP[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, TextConceP[playerid][2], 0);
    return 1;
}
stock CriarRadinho(playerid)
{
    //_-_-_-_-_-RADINHO-_-_-_-_-_//
    RadinhoTextP[playerid][0] = CreatePlayerTextDraw(playerid, 178.000000, 409.000000, "1000");
    PlayerTextDrawFont(playerid, RadinhoTextP[playerid][0], 2);
    PlayerTextDrawLetterSize(playerid, RadinhoTextP[playerid][0], 0.175000, 1.250000);
    PlayerTextDrawTextSize(playerid, RadinhoTextP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, RadinhoTextP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, RadinhoTextP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, RadinhoTextP[playerid][0], 2);
    PlayerTextDrawColor(playerid, RadinhoTextP[playerid][0], 255);
    PlayerTextDrawBackgroundColor(playerid, RadinhoTextP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, RadinhoTextP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, RadinhoTextP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, RadinhoTextP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, RadinhoTextP[playerid][0], 0);
    return 1;
}
stock CriarArmas(playerid)
{
    //_-_-_-_-_-FABRICA DE ARMAS-_-_-_-_-_//
    FabricaDeArmas[playerid][0] = CreatePlayerTextDraw(playerid, 164.000000, 78.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][0], 5);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][0], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][0], 304.000000, 290.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][0], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][0], 0);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][0], 255);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][0], 0);
    PlayerTextDrawSetPreviewModel(playerid, FabricaDeArmas[playerid][0], 2115);
    PlayerTextDrawSetPreviewRot(playerid, FabricaDeArmas[playerid][0], -90.000000, 0.000000, 0.000000, 1.049998);
    PlayerTextDrawSetPreviewVehCol(playerid, FabricaDeArmas[playerid][0], 1, 1);

    FabricaDeArmas[playerid][1] = CreatePlayerTextDraw(playerid, 181.000000, 253.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][1], 5);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][1], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][1], 75.500000, 86.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][1], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][1], 0);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][1], 255);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][1], 0);
    PlayerTextDrawSetPreviewModel(playerid, FabricaDeArmas[playerid][1], 18635);
    PlayerTextDrawSetPreviewRot(playerid, FabricaDeArmas[playerid][1], -10.000000, 39.000000, 4.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, FabricaDeArmas[playerid][1], 1, 1);

    FabricaDeArmas[playerid][2] = CreatePlayerTextDraw(playerid, 357.000000, 254.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][2], 5);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][2], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][2], 123.000000, 155.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][2], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][2], 0);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][2], 255);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][2], 0);
    PlayerTextDrawSetPreviewModel(playerid, FabricaDeArmas[playerid][2], 18644);
    PlayerTextDrawSetPreviewRot(playerid, FabricaDeArmas[playerid][2], -6.000000, -217.000000, -20.000000, 1.569998);
    PlayerTextDrawSetPreviewVehCol(playerid, FabricaDeArmas[playerid][2], 1, 1);

    FabricaDeArmas[playerid][3] = CreatePlayerTextDraw(playerid, 150.000000, 177.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][3], 5);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][3], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][3], 100.000000, 151.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][3], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][3], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][3], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][3], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][3], 0);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][3], 255);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][3], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][3], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][3], 0);
    PlayerTextDrawSetPreviewModel(playerid, FabricaDeArmas[playerid][3], 2034);
    PlayerTextDrawSetPreviewRot(playerid, FabricaDeArmas[playerid][3], 87.000000, -186.000000, -19.000000, 1.569998);
    PlayerTextDrawSetPreviewVehCol(playerid, FabricaDeArmas[playerid][3], 1, 1);

    FabricaDeArmas[playerid][4] = CreatePlayerTextDraw(playerid, 250.000000, 143.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][4], 5);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][4], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][4], 203.000000, 271.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][4], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][4], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][4], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][4], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][4], 0);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][4], 255);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][4], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][4], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][4], 0);
    PlayerTextDrawSetPreviewModel(playerid, FabricaDeArmas[playerid][4], 356);
    PlayerTextDrawSetPreviewRot(playerid, FabricaDeArmas[playerid][4], -10.000000, 0.000000, 9.000000, 2.479999);
    PlayerTextDrawSetPreviewVehCol(playerid, FabricaDeArmas[playerid][4], 1, 1);

    FabricaDeArmas[playerid][5] = CreatePlayerTextDraw(playerid, 230.000000, 294.000000, "Materiais_800~n~Municoes_800");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][5], 2);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][5], 0.166666, 1.200000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][5], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][5], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][5], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][5], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][5], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][5], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][5], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][5], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][5], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][5], 0);

    FabricaDeArmas[playerid][6] = CreatePlayerTextDraw(playerid, 264.000000, 325.000000, "ld_beat:left");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][6], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][6], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][6], 17.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][6], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][6], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][6], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][6], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][6], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][6], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][6], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][6], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][6], 1);

    FabricaDeArmas[playerid][7] = CreatePlayerTextDraw(playerid, 355.000000, 325.000000, "ld_beat:right");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][7], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][7], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][7], 17.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][7], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][7], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][7], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][7], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][7], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][7], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][7], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][7], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][7], 1);

    FabricaDeArmas[playerid][8] = CreatePlayerTextDraw(playerid, 442.000000, 212.000000, "ld_beat:chit");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][8], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][8], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][8], 20.500000, 23.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][8], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][8], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][8], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][8], -256);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][8], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][8], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][8], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][8], 1);

    FabricaDeArmas[playerid][9] = CreatePlayerTextDraw(playerid, 452.000000, 218.000000, "X");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][9], 1);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][9], 0.300000, 1.299998);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][9], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][9], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][9], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][9], 2);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][9], -16776961);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][9], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][9], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][9], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][9], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][9], 0);

    FabricaDeArmas[playerid][10] = CreatePlayerTextDraw(playerid, 291.000000, 325.000000, "ld_dual:white");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][10], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][10], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][10], 54.000000, 16.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][10], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][10], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][10], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][10], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][10], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][10], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][10], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][10], 1);

    FabricaDeArmas[playerid][11] = CreatePlayerTextDraw(playerid, 318.000000, 327.000000, "FABRICAR");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][11], 1);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][11], 0.300000, 1.299998);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][11], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][11], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][11], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][11], 2);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][11], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][11], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][11], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][11], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][11], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][11], 0);

    FabricaDeArmas[playerid][12] = CreatePlayerTextDraw(playerid, 273.000000, 181.000000, "ld_beat:chit");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][12], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][12], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][12], 17.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][12], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][12], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][12], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][12], -1523963137);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][12], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][12], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][12], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][12], 0);

    FabricaDeArmas[playerid][13] = CreatePlayerTextDraw(playerid, 345.000000, 181.000000, "ld_beat:chit");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][13], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][13], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][13], 17.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][13], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][13], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][13], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][13], -1523963137);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][13], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][13], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][13], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][13], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][13], 0);

    FabricaDeArmas[playerid][14] = CreatePlayerTextDraw(playerid, 280.000000, 184.000000, "ld_dual:white");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][14], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][14], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][14], 74.500000, 16.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][14], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][14], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][14], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][14], -1523963137);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][14], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][14], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][14], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][14], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][14], 0);

    FabricaDeArmas[playerid][15] = CreatePlayerTextDraw(playerid, 276.000000, 197.000000, "ld_dual:white");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][15], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][15], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][15], 83.500000, 12.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][15], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][15], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][15], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][15], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][15], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][15], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][15], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][15], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][15], 0);

    FabricaDeArmas[playerid][16] = CreatePlayerTextDraw(playerid, 276.000000, 190.000000, "ld_dual:white");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][16], 4);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][16], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][16], 83.500000, 8.500000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][16], 1);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][16], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][16], 1);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][16], -1523963137);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][16], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][16], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][16], 1);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][16], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][16], 0);

    FabricaDeArmas[playerid][17] = CreatePlayerTextDraw(playerid, 317.000000, 187.000000, "MATERIAIS_DA_ORG");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][17], 1);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][17], 0.204166, 1.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][17], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][17], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][17], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][17], 2);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][17], -1);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][17], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][17], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][17], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][17], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][17], 0);

    FabricaDeArmas[playerid][18] = CreatePlayerTextDraw(playerid, 317.000000, 199.000000, "1000000");
    PlayerTextDrawFont(playerid, FabricaDeArmas[playerid][18], 1);
    PlayerTextDrawLetterSize(playerid, FabricaDeArmas[playerid][18], 0.204166, 1.000000);
    PlayerTextDrawTextSize(playerid, FabricaDeArmas[playerid][18], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, FabricaDeArmas[playerid][18], 0);
    PlayerTextDrawSetShadow(playerid, FabricaDeArmas[playerid][18], 0);
    PlayerTextDrawAlignment(playerid, FabricaDeArmas[playerid][18], 2);
    PlayerTextDrawColor(playerid, FabricaDeArmas[playerid][18], 255);
    PlayerTextDrawBackgroundColor(playerid, FabricaDeArmas[playerid][18], 255);
    PlayerTextDrawBoxColor(playerid, FabricaDeArmas[playerid][18], 50);
    PlayerTextDrawUseBox(playerid, FabricaDeArmas[playerid][18], 0);
    PlayerTextDrawSetProportional(playerid, FabricaDeArmas[playerid][18], 1);
    PlayerTextDrawSetSelectable(playerid, FabricaDeArmas[playerid][18], 0);
    return 1;
}
stock CriarEditor(playerid)
{
    //_-_-_-_-_-EDITOR DE PORTAO-_-_-_-_-_//
    PTDEditorObjetos[playerid][0] = CreatePlayerTextDraw(playerid, 200.6807, 184.4997, "EDITANDO_ROTACAO"); // nope
    PlayerTextDrawLetterSize(playerid, PTDEditorObjetos[playerid][0], 0.1668, 1.2364);
    PlayerTextDrawTextSize(playerid, PTDEditorObjetos[playerid][0], 0.0000, 97.0000);
    PlayerTextDrawAlignment(playerid, PTDEditorObjetos[playerid][0], 2);
    PlayerTextDrawColor(playerid, PTDEditorObjetos[playerid][0], -1);
    PlayerTextDrawUseBox(playerid, PTDEditorObjetos[playerid][0], 1);
    PlayerTextDrawBoxColor(playerid, PTDEditorObjetos[playerid][0], -2147418256);
    PlayerTextDrawSetOutline(playerid, PTDEditorObjetos[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, PTDEditorObjetos[playerid][0], 255);
    PlayerTextDrawFont(playerid, PTDEditorObjetos[playerid][0], 2);
    PlayerTextDrawSetProportional(playerid, PTDEditorObjetos[playerid][0], 1);
    PlayerTextDrawSetShadow(playerid, PTDEditorObjetos[playerid][0], 0);

    PTDEditorObjetos[playerid][1] = CreatePlayerTextDraw(playerid, 200.6807, 201.8995, "Velocidade:_0.1(m)"); // nope
    PlayerTextDrawLetterSize(playerid, PTDEditorObjetos[playerid][1], 0.1668, 1.2364);
    PlayerTextDrawTextSize(playerid, PTDEditorObjetos[playerid][1], 0.0000, 97.0000);
    PlayerTextDrawAlignment(playerid, PTDEditorObjetos[playerid][1], 2);
    PlayerTextDrawColor(playerid, PTDEditorObjetos[playerid][1], -1);
    PlayerTextDrawUseBox(playerid, PTDEditorObjetos[playerid][1], 1);
    PlayerTextDrawBoxColor(playerid, PTDEditorObjetos[playerid][1], -2147418256);
    PlayerTextDrawSetOutline(playerid, PTDEditorObjetos[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, PTDEditorObjetos[playerid][1], 255);
    PlayerTextDrawFont(playerid, PTDEditorObjetos[playerid][1], 2);
    PlayerTextDrawSetProportional(playerid, PTDEditorObjetos[playerid][1], 1);
    PlayerTextDrawSetShadow(playerid, PTDEditorObjetos[playerid][1], 0);
    return 1;
}
stock CriarSkin(playerid)
{
    //_-_-_-_-_-SKINS-_-_-_-_-_//
    TextSkinMenuP[playerid][0] = CreatePlayerTextDraw(playerid, 287.000000, 340.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, TextSkinMenuP[playerid][0], 5);
    PlayerTextDrawLetterSize(playerid, TextSkinMenuP[playerid][0], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, TextSkinMenuP[playerid][0], 59.500000, 63.000000);
    PlayerTextDrawSetOutline(playerid, TextSkinMenuP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, TextSkinMenuP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, TextSkinMenuP[playerid][0], 1);
    PlayerTextDrawColor(playerid, TextSkinMenuP[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, TextSkinMenuP[playerid][0], 0);
    PlayerTextDrawBoxColor(playerid, TextSkinMenuP[playerid][0], 255);
    PlayerTextDrawUseBox(playerid, TextSkinMenuP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, TextSkinMenuP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, TextSkinMenuP[playerid][0], 0);
    PlayerTextDrawSetPreviewModel(playerid, TextSkinMenuP[playerid][0], 265);
    PlayerTextDrawSetPreviewRot(playerid, TextSkinMenuP[playerid][0], -10.000000, 0.000000, -7.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, TextSkinMenuP[playerid][0], 1, 1);

    TextSkinMenuP[playerid][1] = CreatePlayerTextDraw(playerid, 273.000000, 405.000000, "ID:_265");
    PlayerTextDrawFont(playerid, TextSkinMenuP[playerid][1], 2);
    PlayerTextDrawLetterSize(playerid, TextSkinMenuP[playerid][1], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, TextSkinMenuP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TextSkinMenuP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, TextSkinMenuP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, TextSkinMenuP[playerid][1], 2);
    PlayerTextDrawColor(playerid, TextSkinMenuP[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, TextSkinMenuP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, TextSkinMenuP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, TextSkinMenuP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, TextSkinMenuP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, TextSkinMenuP[playerid][1], 0);

    TextSkinMenuP[playerid][2] = CreatePlayerTextDraw(playerid, 365.000000, 405.000000, "R$:5000");
    PlayerTextDrawFont(playerid, TextSkinMenuP[playerid][2], 2);
    PlayerTextDrawLetterSize(playerid, TextSkinMenuP[playerid][2], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, TextSkinMenuP[playerid][2], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TextSkinMenuP[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, TextSkinMenuP[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, TextSkinMenuP[playerid][2], 2);
    PlayerTextDrawColor(playerid, TextSkinMenuP[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, TextSkinMenuP[playerid][2], 255);
    PlayerTextDrawBoxColor(playerid, TextSkinMenuP[playerid][2], 50);
    PlayerTextDrawUseBox(playerid, TextSkinMenuP[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, TextSkinMenuP[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, TextSkinMenuP[playerid][2], 0);
    return 1;
}
stock CriarLog(playerid)
{
    //_-_-_-_-_-LOGIN-_-_-_-_-_//
    Log_LifeP[playerid][0] = CreatePlayerTextDraw(playerid, 102.000000, 182.000000, "Luis_Bolado");
    PlayerTextDrawFont(playerid, Log_LifeP[playerid][0], 2);
    PlayerTextDrawLetterSize(playerid, Log_LifeP[playerid][0], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Log_LifeP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Log_LifeP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, Log_LifeP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, Log_LifeP[playerid][0], 2);
    PlayerTextDrawColor(playerid, Log_LifeP[playerid][0], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Log_LifeP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, Log_LifeP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, Log_LifeP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, Log_LifeP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, Log_LifeP[playerid][0], 0);

    Log_LifeP[playerid][1] = CreatePlayerTextDraw(playerid, 102.000000, 227.000000, "123456789");
    PlayerTextDrawFont(playerid, Log_LifeP[playerid][1], 2);
    PlayerTextDrawLetterSize(playerid, Log_LifeP[playerid][1], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Log_LifeP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Log_LifeP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, Log_LifeP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, Log_LifeP[playerid][1], 2);
    PlayerTextDrawColor(playerid, Log_LifeP[playerid][1], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Log_LifeP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, Log_LifeP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, Log_LifeP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, Log_LifeP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, Log_LifeP[playerid][1], 0);
    return 1;
}
stock CriarReg(playerid)
{
    //_-_-_-_-_-REGISTRO-_-_-_-_-_//
    Reg_LifeP[playerid][0] = CreatePlayerTextDraw(playerid, 102.000000, 182.000000, "Luis_Bolado");
    PlayerTextDrawFont(playerid, Reg_LifeP[playerid][0], 2);
    PlayerTextDrawLetterSize(playerid, Reg_LifeP[playerid][0], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Reg_LifeP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Reg_LifeP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, Reg_LifeP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, Reg_LifeP[playerid][0], 2);
    PlayerTextDrawColor(playerid, Reg_LifeP[playerid][0], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Reg_LifeP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, Reg_LifeP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, Reg_LifeP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, Reg_LifeP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, Reg_LifeP[playerid][0], 0);

    Reg_LifeP[playerid][1] = CreatePlayerTextDraw(playerid, 102.000000, 227.000000, "123456789");
    PlayerTextDrawFont(playerid, Reg_LifeP[playerid][1], 2);
    PlayerTextDrawLetterSize(playerid, Reg_LifeP[playerid][1], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Reg_LifeP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Reg_LifeP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, Reg_LifeP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, Reg_LifeP[playerid][1], 2);
    PlayerTextDrawColor(playerid, Reg_LifeP[playerid][1], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Reg_LifeP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, Reg_LifeP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, Reg_LifeP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, Reg_LifeP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, Reg_LifeP[playerid][1], 0);

    Reg_LifeP[playerid][2] = CreatePlayerTextDraw(playerid, 102.000000, 272.000000, "LULU1242");
    PlayerTextDrawFont(playerid, Reg_LifeP[playerid][2], 2);
    PlayerTextDrawLetterSize(playerid, Reg_LifeP[playerid][2], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Reg_LifeP[playerid][2], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Reg_LifeP[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, Reg_LifeP[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, Reg_LifeP[playerid][2], 2);
    PlayerTextDrawColor(playerid, Reg_LifeP[playerid][2], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Reg_LifeP[playerid][2], 255);
    PlayerTextDrawBoxColor(playerid, Reg_LifeP[playerid][2], 50);
    PlayerTextDrawUseBox(playerid, Reg_LifeP[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, Reg_LifeP[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, Reg_LifeP[playerid][2], 0);

    Reg_LifeP[playerid][3] = CreatePlayerTextDraw(playerid, 102.000000, 316.000000, "LRP@gmail.com");
    PlayerTextDrawFont(playerid, Reg_LifeP[playerid][3], 2);
    PlayerTextDrawLetterSize(playerid, Reg_LifeP[playerid][3], 0.137500, 0.949998);
    PlayerTextDrawTextSize(playerid, Reg_LifeP[playerid][3], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Reg_LifeP[playerid][3], 0);
    PlayerTextDrawSetShadow(playerid, Reg_LifeP[playerid][3], 0);
    PlayerTextDrawAlignment(playerid, Reg_LifeP[playerid][3], 2);
    PlayerTextDrawColor(playerid, Reg_LifeP[playerid][3], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Reg_LifeP[playerid][3], 255);
    PlayerTextDrawBoxColor(playerid, Reg_LifeP[playerid][3], 50);
    PlayerTextDrawUseBox(playerid, Reg_LifeP[playerid][3], 0);
    PlayerTextDrawSetProportional(playerid, Reg_LifeP[playerid][3], 1);
    PlayerTextDrawSetSelectable(playerid, Reg_LifeP[playerid][3], 0);

    Reg_LifeP[playerid][4] = CreatePlayerTextDraw(playerid, 537.000000, 223.000000, "19");
    PlayerTextDrawFont(playerid, Reg_LifeP[playerid][4], 2);
    PlayerTextDrawLetterSize(playerid, Reg_LifeP[playerid][4], 0.158333, 1.049998);
    PlayerTextDrawTextSize(playerid, Reg_LifeP[playerid][4], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, Reg_LifeP[playerid][4], 0);
    PlayerTextDrawSetShadow(playerid, Reg_LifeP[playerid][4], 0);
    PlayerTextDrawAlignment(playerid, Reg_LifeP[playerid][4], 2);
    PlayerTextDrawColor(playerid, Reg_LifeP[playerid][4], 1296911871);
    PlayerTextDrawBackgroundColor(playerid, Reg_LifeP[playerid][4], 255);
    PlayerTextDrawBoxColor(playerid, Reg_LifeP[playerid][4], 50);
    PlayerTextDrawUseBox(playerid, Reg_LifeP[playerid][4], 0);
    PlayerTextDrawSetProportional(playerid, Reg_LifeP[playerid][4], 1);
    PlayerTextDrawSetSelectable(playerid, Reg_LifeP[playerid][4], 0);
    return 1;
}

stock criarcarregamento(playerid)
{
    //_-_-_-_-_-TELA CARREGAMENTO-_-_-_-_-_//
    TelaCarregamentoP[playerid][0] = CreatePlayerTextDraw(playerid, 132.000000, 324.000000, "ld_dual:white");
    PlayerTextDrawFont(playerid, TelaCarregamentoP[playerid][0], 4);
    PlayerTextDrawLetterSize(playerid, TelaCarregamentoP[playerid][0], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, TelaCarregamentoP[playerid][0], 375.500000, 5.000000);
    PlayerTextDrawSetOutline(playerid, TelaCarregamentoP[playerid][0], 1);
    PlayerTextDrawSetShadow(playerid, TelaCarregamentoP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, TelaCarregamentoP[playerid][0], 1);
    PlayerTextDrawColor(playerid, TelaCarregamentoP[playerid][0], -208139521);
    PlayerTextDrawBackgroundColor(playerid, TelaCarregamentoP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, TelaCarregamentoP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, TelaCarregamentoP[playerid][0], 1);
    PlayerTextDrawSetProportional(playerid, TelaCarregamentoP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, TelaCarregamentoP[playerid][0], 0);

    TelaCarregamentoP[playerid][1] = CreatePlayerTextDraw(playerid, 132.000000, 331.000000, "Server/Files/Data/Data.rar");
    PlayerTextDrawFont(playerid, TelaCarregamentoP[playerid][1], 1);
    PlayerTextDrawLetterSize(playerid, TelaCarregamentoP[playerid][1], 0.162497, 0.749998);
    PlayerTextDrawTextSize(playerid, TelaCarregamentoP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, TelaCarregamentoP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, TelaCarregamentoP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, TelaCarregamentoP[playerid][1], 1);
    PlayerTextDrawColor(playerid, TelaCarregamentoP[playerid][1], 1347440895);
    PlayerTextDrawBackgroundColor(playerid, TelaCarregamentoP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, TelaCarregamentoP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, TelaCarregamentoP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, TelaCarregamentoP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, TelaCarregamentoP[playerid][1], 0);
    return 1;
}
stock Criartelapp(playerid)
{
    //_-_-_-_-_-TELA PRETA-_-_-_-_-_//
    TextTelaPreta[playerid] = CreatePlayerTextDraw(playerid, -47.335281, -64.333335, "box");
    PlayerTextDrawLetterSize(playerid, TextTelaPreta[playerid], 0.000000, 58.726200);
    PlayerTextDrawTextSize(playerid, TextTelaPreta[playerid], 659.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, TextTelaPreta[playerid], 1);
    PlayerTextDrawColor(playerid, TextTelaPreta[playerid], -1);
    PlayerTextDrawUseBox(playerid, TextTelaPreta[playerid], 1);
    PlayerTextDrawBoxColor(playerid, TextTelaPreta[playerid], 255);
    PlayerTextDrawSetShadow(playerid, TextTelaPreta[playerid], 0);
    PlayerTextDrawSetOutline(playerid, TextTelaPreta[playerid], 0);
    PlayerTextDrawBackgroundColor(playerid, TextTelaPreta[playerid], 255);
    PlayerTextDrawFont(playerid, TextTelaPreta[playerid], 1);
    PlayerTextDrawSetProportional(playerid, TextTelaPreta[playerid], 1);
    PlayerTextDrawSetShadow(playerid, TextTelaPreta[playerid], 0);
    return 1;
}
stock criarleite(playerid)
{
    //_-_-_-_-_-LEITEIRO-_-_-_-_-_//
    LeiteroTDP[playerid][0] = CreatePlayerTextDraw(playerid, 319.000000, 235.000000, "00:59");
    PlayerTextDrawFont(playerid, LeiteroTDP[playerid][0], 1);
    PlayerTextDrawLetterSize(playerid, LeiteroTDP[playerid][0], 0.225000, 1.149999);
    PlayerTextDrawTextSize(playerid, LeiteroTDP[playerid][0], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, LeiteroTDP[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, LeiteroTDP[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, LeiteroTDP[playerid][0], 2);
    PlayerTextDrawColor(playerid, LeiteroTDP[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, LeiteroTDP[playerid][0], 255);
    PlayerTextDrawBoxColor(playerid, LeiteroTDP[playerid][0], 50);
    PlayerTextDrawUseBox(playerid, LeiteroTDP[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, LeiteroTDP[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, LeiteroTDP[playerid][0], 0);

    LeiteroTDP[playerid][1] = CreatePlayerTextDraw(playerid, 318.000000, 432.000000, "50L");
    PlayerTextDrawFont(playerid, LeiteroTDP[playerid][1], 1);
    PlayerTextDrawLetterSize(playerid, LeiteroTDP[playerid][1], 0.158333, 0.899999);
    PlayerTextDrawTextSize(playerid, LeiteroTDP[playerid][1], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, LeiteroTDP[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, LeiteroTDP[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, LeiteroTDP[playerid][1], 1);
    PlayerTextDrawColor(playerid, LeiteroTDP[playerid][1], -8388353);
    PlayerTextDrawBackgroundColor(playerid, LeiteroTDP[playerid][1], 255);
    PlayerTextDrawBoxColor(playerid, LeiteroTDP[playerid][1], 50);
    PlayerTextDrawUseBox(playerid, LeiteroTDP[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, LeiteroTDP[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, LeiteroTDP[playerid][1], 0);
    return 1;
}
stock CriarCraft(playerid)
{
    //_-_-_-_-_-CRAFT-_-_-_-_-_//
    CraftPTD[playerid][0] = CreatePlayerTextDraw(playerid, 296.000000, 322.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][0], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][0], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][0], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][0], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][0], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][0], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][0], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][0], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][0], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][0], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][0], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][0], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][0], 1, 1);

    CraftPTD[playerid][1] = CreatePlayerTextDraw(playerid, 181.000000, 231.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][1], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][1], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][1], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][1], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][1], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][1], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][1], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][1], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][1], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][1], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][1], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][1], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][1], 1, 1);

    CraftPTD[playerid][2] = CreatePlayerTextDraw(playerid, 238.000000, 231.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][2], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][2], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][2], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][2], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][2], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][2], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][2], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][2], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][2], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][2], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][2], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][2], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][2], 1, 1);

    CraftPTD[playerid][3] = CreatePlayerTextDraw(playerid, 296.000000, 231.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][3], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][3], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][3], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][3], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][3], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][3], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][3], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][3], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][3], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][3], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][3], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][3], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][3], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][3], 1, 1);

    CraftPTD[playerid][4] = CreatePlayerTextDraw(playerid, 354.000000, 231.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][4], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][4], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][4], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][4], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][4], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][4], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][4], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][4], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][4], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][4], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][4], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][4], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][4], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][4], 1, 1);

    CraftPTD[playerid][5] = CreatePlayerTextDraw(playerid, 411.000000, 231.000000, "Preview_Model");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][5], 5);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][5], 0.600000, 2.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][5], 47.500000, 48.500000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][5], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][5], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][5], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][5], 623191551);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][5], 255);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][5], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][5], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][5], 0);
    PlayerTextDrawSetPreviewModel(playerid, CraftPTD[playerid][5], 0);
    PlayerTextDrawSetPreviewRot(playerid, CraftPTD[playerid][5], -10.000000, 0.000000, -20.000000, 1.000000);
    PlayerTextDrawSetPreviewVehCol(playerid, CraftPTD[playerid][5], 1, 1);

    CraftPTD[playerid][6] = CreatePlayerTextDraw(playerid, 205.000000, 284.000000, "~g~10/5");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][6], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][6], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][6], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][6], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][6], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][6], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][6], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][6], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][6], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][6], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][6], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][6], 0);

    CraftPTD[playerid][7] = CreatePlayerTextDraw(playerid, 262.000000, 284.000000, "~g~10/5");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][7], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][7], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][7], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][7], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][7], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][7], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][7], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][7], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][7], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][7], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][7], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][7], 0);

    CraftPTD[playerid][8] = CreatePlayerTextDraw(playerid, 320.000000, 284.000000, "~g~10/5");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][8], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][8], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][8], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][8], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][8], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][8], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][8], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][8], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][8], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][8], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][8], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][8], 0);

    CraftPTD[playerid][9] = CreatePlayerTextDraw(playerid, 378.000000, 284.000000, "~g~10/5");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][9], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][9], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][9], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][9], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][9], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][9], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][9], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][9], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][9], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][9], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][9], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][9], 0);

    CraftPTD[playerid][10] = CreatePlayerTextDraw(playerid, 435.000000, 284.000000, "~g~10/5");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][10], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][10], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][10], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][10], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][10], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][10], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][10], 16711935);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][10], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][10], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][10], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][10], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][10], 0);

    CraftPTD[playerid][11] = CreatePlayerTextDraw(playerid, 320.000000, 309.000000, "ELETRONICO");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][11], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][11], 0.158333, 1.049999);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][11], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][11], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][11], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][11], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][11], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][11], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][11], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][11], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][11], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][11], 0);

    CraftPTD[playerid][12] = CreatePlayerTextDraw(playerid, 320.000000, 187.000000, "MESA_DE_CRAFT");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][12], 3);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][12], 0.383332, 1.600000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][12], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][12], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][12], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][12], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][12], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][12], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][12], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][12], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][12], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][12], 0);

    CraftPTD[playerid][13] = CreatePlayerTextDraw(playerid, 221.000000, 356.000000, "FECHAR");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][13], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][13], 0.158333, 1.049999);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][13], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][13], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][13], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][13], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][13], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][13], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][13], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][13], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][13], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][13], 0);

    CraftPTD[playerid][14] = CreatePlayerTextDraw(playerid, 419.000000, 356.000000, "CRAFT");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][14], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][14], 0.158333, 1.049999);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][14], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][14], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][14], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][14], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][14], -1);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][14], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][14], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][14], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][14], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][14], 0);

    CraftPTD[playerid][15] = CreatePlayerTextDraw(playerid, 419.000000, 337.000000, "~g~$10000");
    PlayerTextDrawFont(playerid, CraftPTD[playerid][15], 2);
    PlayerTextDrawLetterSize(playerid, CraftPTD[playerid][15], 0.158333, 1.000000);
    PlayerTextDrawTextSize(playerid, CraftPTD[playerid][15], 400.000000, 17.000000);
    PlayerTextDrawSetOutline(playerid, CraftPTD[playerid][15], 0);
    PlayerTextDrawSetShadow(playerid, CraftPTD[playerid][15], 0);
    PlayerTextDrawAlignment(playerid, CraftPTD[playerid][15], 2);
    PlayerTextDrawColor(playerid, CraftPTD[playerid][15], 16711935);
    PlayerTextDrawBackgroundColor(playerid, CraftPTD[playerid][15], 255);
    PlayerTextDrawBoxColor(playerid, CraftPTD[playerid][15], 50);
    PlayerTextDrawUseBox(playerid, CraftPTD[playerid][15], 0);
    PlayerTextDrawSetProportional(playerid, CraftPTD[playerid][15], 1);
    PlayerTextDrawSetSelectable(playerid, CraftPTD[playerid][15], 0);
    return 1;
}
