	//����� ��������
    door[0] = CreateObject(1495, -1786.7758, -1998.9715, 1499.7488, 0.000000, 0.000000, 90.000000);
	SetObjectMaterial(door[0], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[0], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[0], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//
	door[1] = CreateObject(1495, -1757.904175, -1998.991455, 1499.748779, 0.000000, 0.000000, 90.000000);
	SetObjectMaterial(door[1], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[1], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[1], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//
	door[2] = CreateObject(1495, -1773.273926, -1995.144531, 1499.748779, 0.000000, 0.000000, 0.000000);
	SetObjectMaterial(door[2], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[2], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[2], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//�����
	door[3] = CreateObject(1495, -2067.669922, 2693.154053, 1499.956177, 0.000000, 0.000000, 90.000000);
	SetObjectMaterial(door[3], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[3], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[3], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//
	door[4] = CreateObject(1495, -2062.227539, 2694.687500, 1499.956177, 0.000000, 0.000000, -90.000000);
	SetObjectMaterial(door[4], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[4], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[4], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//
	door[5] = CreateObject(1495, -2067.672607, 2704.733398, 1499.956177, 0.000000, 0.000000, 90.000000);
	SetObjectMaterial(door[5], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[5], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[5], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//
	door[6] = CreateObject(1495, -2062.210693, 2706.245605, 1499.956177, 0.000000, 0.000000, -90.000000);
	SetObjectMaterial(door[6], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[6], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[6], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//����
	door[7] = CreateObject(1495, -2690.825928, 807.425110, 1499.940430, 0.000000, 0.000000, 0.000000);
	SetObjectMaterial(door[7], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[7], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[7], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//���������
	door[8] = CreateObject(1495, -2583.000000, -1385.292358, 1499.737549, 0.000000, 0.000000, 90.000000);
	SetObjectMaterial(door[8], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[8], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[8], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//���������
	door[9] = CreateObject(1495, -169.981903, 1345.068726, 1499.968750, 0.000000, 0.000000, 270.000000);
	SetObjectMaterial(door[9], 2, 3440, "airportpillar", "metalic_64", 0);
	SetObjectMaterial(door[9], 1, 4830, "airport2", "sanairtex3", 0);
	SetObjectMaterial(door[9], 0, 3440, "airportpillar", "metalic_64", 0xFFD3D3D3);
	//////////////////////////////////////////////////////////////////////////////////////