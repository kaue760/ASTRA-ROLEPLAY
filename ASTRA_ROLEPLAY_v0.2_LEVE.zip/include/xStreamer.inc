/*  
	xStreamer by Boylett
 */

#if defined _xstreamer_included
	#endinput
#endif
#define _xstreamer_included
#pragma library xstreamer

#include <a_samp>

//------------------------------------------------------------------------------

native CreateStreamedObject(modelid,Float:x,Float:y,Float:z,Float:rx,Float:ry,Float:rz);
native DestroyStreamedObject(objectid);
native MoveStreamedObject(objectid,Float:x,Float:y,Float:z,Float:speed);
native StopStreamedObject(objectid);
native DestroyObjectsCreatedByMe();
native StreamObjects(playerid,Float:x,Float:y,Float:z);

stock xStreamer_SetPlayerPos(playerid,Float:x,Float:y,Float:z)
{
	StreamObjects(playerid,x,y,z);
	SetPlayerPos(playerid,x,y,z);
}

#if !defined DONT_REPLACE_NATIVES

#define SetPlayerPos xStreamer_SetPlayerPos
#define CreateObject CreateStreamedObject
#define DestroyObject DestroyStreamedObject
#define MoveObject MoveStreamedObject
#define StopObject StopStreamedObject

#endif