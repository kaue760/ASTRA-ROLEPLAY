/* Creditos a Poderoso Chef�o
Como Usar:
Passo 1: Substitua GetPlayerMoney por K_DarDinheiro
Passo 2: Substitua GetPlayerMoney por K_GetarDinheiro
Passo 3: Substitua ResetPlayerMoney por K_ResetarDinheiro
Passo 4: Adicione a fun��o K_AtualizarDinheiro(playerid); na public OnPlayerUpdate(playerid)
Extra: para escolher a vers�o que deseja utilizar Defina VERSAO_DO_SAMP (Defina 0 para 0.2x ou Defina 1 para 0.3b)
Creditos: Poderoso Chef�o
native K_DarDinheiro(playerid,Dinheiro);
native K_SetarDinheiro(playerid,Dinheiro);
native K_GetarDinheiro(playerid);
native K_ResetarDinheiro(playerid);
native K_AtualizarDinheiro(playerid);
*/
#include <a_samp>
#define VERSAO_DO_SAMP 1 // Defina 0 para 0.2x ou Defina 1 para 0.3b mais
#if VERSAO_DO_SAMP == 1
stock K_DarDinheiro(playerid,Dinheiro) return SetPVarInt(playerid,"dinheiro",GetPVarInt(playerid,"dinheiro")+Dinheiro);
stock K_SetarDinheiro(playerid,Dinheiro) return SetPVarInt(playerid,"dinheiro",Dinheiro);
stock K_GetarDinheiro(playerid) return GetPVarInt(playerid,"dinheiro");
stock K_ResetarDinheiro(playerid) return SetPVarInt(playerid,"dinheiro",0);
stock ChefaoSetarDinheiro(playerid) { ResetPlayerMoney(playerid); GivePlayerMoney(playerid, GetPVarInt(playerid,"dinheiro")); }
stock K_AtualizarDinheiro(playerid) if(GetPlayerMoney(playerid) != GetPVarInt(playerid,"dinheiro")) ChefaoSetarDinheiro(playerid);
#endif
#if VERSAO_DO_SAMP == 0
new K_Dinheiro[MAX_PLAYERS];
stock K_DarDinheiro(playerid,Dinheiro) return K_Dinheiro[playerid] += Dinheiro;
stock K_SetarDinheiro(playerid,Dinheiro) return K_Dinheiro[playerid] = Dinheiro;
stock K_GetarDinheiro(playerid) return K_Dinheiro[playerid];
stock K_ResetarDinheiro(playerid) return K_Dinheiro[playerid] = 0;
stock ChefaoSetarDinheiro(playerid) { ResetPlayerMoney(playerid); GivePlayerMoney(playerid, K_Dinheiro[playerid]); }
stock K_AtualizarDinheiro(playerid) if(GetPlayerMoney(playerid) != K_Dinheiro[playerid]) ChefaoSetarDinheiro(playerid);
#endif