#include <a_samp>
/* NATIVAS <
C_GetNomeCarros(modeloid);//Pegar o nome do veiculo
C_GetAvailableSeat(vehicleid, seat_inicio);//Pegar um assento valido que não tenha sido usado
C_GetVehicleMaxSeats(vehicleid);//pegar o maximo de assento que possui o veiculo
C_GetInfCarros(modeloid);//Pegar A distancia Frente/tras dos veiculos
C_GetTipoCar(modeloid);//Pegar o tipo de veiculo que ele e
C_GetNomePlayer(playerid);//Pegar o nome do jogador
C_GetVida(playerid);//Pegar a quantia de Vida do jogador
C_GetNomeArma(armaid);//Pegar o nome da arma
*/

#if defined _C_Codes_included
	#endinput
#endif
#define _C_Codes_included

stock C_GetNomeArma(armaid){
	new C_Nome[32];
	GetWeaponName(armaid, C_Nome, sizeof(C_Nome));
	return C_Nome;
}

forward Float:C_GetVida(playerid);
public Float:C_GetVida(playerid){
	new Float:C_Vida;
	GetPlayerHealth(playerid,C_Vida);
	return C_Vida;
}

stock C_GetNomePlayer(playerid){
    new C_Nome[MAX_PLAYER_NAME];
	GetPlayerName(playerid, C_Nome, sizeof(C_Nome));
	return C_Nome;
}


new C_NomeCarros[212][32] ={
    {"Landstalker"},{"Bravura"},{"Buffalo"},{"Linerunner"},{"Perrenial"},{"Sentinel"},{"Dumper"},
    {"Firetruck"},{"Trashmaster"},{"Stretch"},{"Manana"},{"Infernus"},{"Voodoo"},{"Pony"},{"Mule"},
    {"Cheetah"},{"Ambulance"},{"Leviathan"},{"Moonbeam"},{"Esperanto"},{"Taxi"},{"Washington"},
    {"Bobcat"},{"Mr Whoopee"},{"BF Injection"},{"Hunter"},{"Premier"},{"Enforcer"},{"Securicar"},
    {"Banshee"},{"Predator"},{"Bus"},{"Rhino"},{"Barracks"},{"Hotknife"},{"Trailer 1"},{"Previon"},
    {"Coach"},{"Cabbie"},{"Stallion"},{"Rumpo"},{"RC Bandit"},{"Romero"},{"Packer"},{"Monster"},
    {"Admiral"},{"Squalo"},{"Seasparrow"},{"Pizzaboy"},{"Tram"},{"Trailer 2"},{"Turismo"},
    {"Speeder"},{"Reefer"},{"Tropic"},{"Flatbed"},{"Yankee"},{"Caddy"},{"Solair"},{"Berkley's RC Van"},
    {"Skimmer"},{"PCJ-600"},{"Faggio"},{"Freeway"},{"RC Baron"},{"RC Raider"},{"Glendale"},{"Oceanic"},
    {"Sanchez"},{"Sparrow"},{"Patriot"},{"Quad"},{"Coastguard"},{"Dinghy"},{"Hermes"},{"Sabre"},
    {"Rustler"},{"ZR-350"},{"Walton"},{"Regina"},{"Comet"},{"BMX"},{"Burrito"},{"Camper"},{"Marquis"},
    {"Baggage"},{"Dozer"},{"Maverick"},{"News Chopper"},{"Rancher"},{"FBI Rancher"},{"Virgo"},{"Greenwood"},
    {"Jetmax"},{"Hotring"},{"Sandking"},{"Blista Compact"},{"Police Maverick"},{"Boxville"},{"Benson"},
    {"Mesa"},{"RC Goblin"},{"Hotring Racer A"},{"Hotring Racer B"},{"Bloodring Banger"},{"Rancher"},
    {"Super GT"},{"Elegant"},{"Journey"},{"Bike"},{"Mountain Bike"},{"Beagle"},{"Cropdust"},{"Stunt"},
    {"Tanker"}, {"Roadtrain"},{"Nebula"},{"Majestic"},{"Buccaneer"},{"Shamal"},{"Hydra"},{"FCR-900"},
    {"NRG-500"},{"HPV1000"},{"Cement Truck"},{"Tow Truck"},{"Fortune"},{"Cadrona"},{"FBI Truck"},
    {"Willard"},{"Forklift"},{"Tractor"},{"Combine"},{"Feltzer"},{"Remington"},{"Slamvan"},
    {"Blade"},{"Freight"},{"Streak"},{"Vortex"},{"Vincent"},{"Bullet"},{"Clover"},{"Sadler"},
    {"Firetruck LA"},{"Hustler"},{"Intruder"},{"Primo"},{"Cargobob"},{"Tampa"},{"Sunrise"},{"Merit"},
    {"Utility"},{"Nevada"},{"Yosemite"},{"Windsor"},{"Monster A"},{"Monster B"},{"Uranus"},{"Jester"},
    {"Sultan"},{"Stratum"},{"Elegy"},{"Raindance"},{"RC Tiger"},{"Flash"},{"Tahoma"},{"Savanna"},
    {"Bandito"},{"Freight Flat"},{"Streak Carriage"},{"Kart"},{"Mower"},{"Duneride"},{"Sweeper"},
    {"Broadway"},{"Tornado"},{"AT-400"},{"DFT-30"},{"Huntley"},{"Stafford"},{"BF-400"},{"Newsvan"},
    {"Tug"},{"Trailer 3"},{"Emperor"},{"Wayfarer"},{"Euros"},{"Hotdog"},{"Club"},{"Freight Carriage"},
    {"Trailer 3"},{"Andromada"},{"Dodo"},{"RC Cam"},{"Launch"},{"Police Car (LSPD)"},{"Police Car (SFPD)"},
    {"Police Car (LVPD)"},{"Police Ranger"},{"Picador"},{"S.W.A.T. Van"},{"Alpha"},{"Phoenix"},{"Glendale"},
    {"Sadler"},{"Luggage Trailer A"},{"Luggage Trailer B"},{"Stair Trailer"},{"Boxville"},{"Farm Plow"},
    {"Utility Trailer"}
};
stock C_GetNomeCarros(modeloid){
	new C_Nome[32];
	if(modeloid >= 400 && modeloid <= 612) C_Nome = C_NomeCarros[modeloid-400];
	else C_Nome = "Nenhum";
	return C_Nome;
}

new Float:C_InfFTCarros[] ={
//0, 1 , 2 , 3 , 4  	, 5 , 6 , 7 , 8 , 9
2.0,2.5,2.5,4.5,5.2		,2.5,5.5,4.5,5.0,4.0,      //0  (400~409)
2.5,2.5,2.5,2.5,2.7 	,2.5,3.0,0.0,2.5,2.5,      //1  (410~419)
2.5,2.5,2.5,2.5,1.5		,2.5,0.0,3.5,2.5,2.5,      //2  (420~429)
4.5,6.0,5.0,4.0,2.0		,0.0,2.5,5.5,2.5,2.5,      //3  (430~439)
2.5,0.5,3.0,6.0,3.0		,2.5,5.0,0.0,1.0,5.0,      //4  (440~449)
5.0,2.5,4.5,5.0,6.0		,4.0,3.5,1.0,2.5,2.5,      //5  (450~459)
0.0,0.0,0.0,0.0,0.0		,0.0,2.5,2.5,0.0,0.0,      //6  (460~469)
2.5,0.0,4.0,2.0,2.5		,2.5,0.0,2.5,2.5,2.5,      //7  (470~479)
2.5,0.0,2.5,3.0,7.0		,2.0,3.5,0.0,0.0,3.0,      //8  (480~489)
3.5,2.5,2.5,4.5,2.5		,2.5,2.5,0.0,3.0,2.5,      //9  (490~499)
0.0,0.0,2.5,2.5,2.5		,2.5,2.5,2.5,3.0,0.0,      //10 (500~509)

0.0,0.0,0.0,0.0,4.5		,4.5,2.5,3.0,2.5,0.0,      //11 (510~519)
0.0,0.0,0.0,0.0,4.0		,3.0,2.5,2.5,2.5,2.5,      //12 (520~529)
1.5,1.5,1.5,2.5,3.0		,2.5,2.5,0.0,0.0,2.0,      //13 (530~539)
2.5,2.5,2.5,2.5,4.0		,2.0,2.5,2.5,0.0,2.5,      //14 (540~549)
2.5,2.5,3.0,0.0,2.5		,2.5,2.5,2.5,2.5,2.5,      //15 (550~559)
2.5,2.5,2.5,0.0,0.0		,2.0,2.5,3.0,2.0,0.0,      //16 (560~569)
0.0,1.0,1.0,3.5,2.0		,2.5,2.5,0.0,5.0,2.5,      //17 (570~579)
2.5,0.0,2.5,1.5,0.0		,2.5,0.0,2.5,3.5,2.5,      //18 (580~589)
0.0,0.0,0.0,0.0,0.0		,5.0,2.5,2.5,2.5,2.5,      //19 (590~599)
0.0,2.5,2.5,2.5,2.5		,2.5,2.5,2.5,2.5,2.5,      //20 (600~609)
2.5,3.0,2.5,2.5,2.5		,2.5,0.0,0.0,0.0,3.0,      //21 (610~619)
0.0,0.0,0.0	     							  	   //22 (613)
};

forward Float:C_GetInfCarros(modeloid);
public Float:C_GetInfCarros(modeloid){
	new Float:C_Code;
	if(modeloid >= 400 && modeloid <= 612) C_Code = C_InfFTCarros[modeloid-400];
	else C_Code = -1.0;
	return C_Code;
}

new C_TypeCarr[]={
// [1.0 = CARRO] , [2.0 = GOVERNO]  , [3.0 = VAN,PICAPE] , [4.0 = SERV] , [5.0 = MOTO] ,  [6.0 = AVIÃO] ,  [7.0 = HELICOP] ,
// [8.0 = TRAILER] ,  [9.0 = Caminhão/Carreta] ,   [1.1 = TREM,RC VEH] ,  [1.2 = BARCO] ,
//1,2,3,4       ,5,6,7,8,9
1,1,1,9,1		,1,9,2,4,1,      //0  (400~409)
1,1,1,3,9		,1,2,7,3,1,      //1  (410~419)
4,1,3,9,1		,7,1,2,2,1,      //2  (420~429)
12,4,2,2,1		,8,1,4,4,1,      //3  (430~439)
3,11,1,9,1		,1,12,7,5,11,    //4  (440~449)
8,1,12,12,12	,9,9,1,1,3,      //5  (450~459)
6,5,5,5,11		,11,1,1,5,7,     //6  (460~469)
2,5,12,12,1		,1,6,1,3,1,      //7  (470~479)
1,5,3,1,12		,4,9,7,7,1,      //8  (480~489)
2,1,1,12,1		,1,1,7,9,9,      //9  (490~499)
5,11,1,1,1		,1,1,1,1,5,      //10 (500~509)

5,6,6,6,9		,9,1,1,1,6,      //11 (510~519)
6,5,5,2,9		,4,1,1,2,1,      //12 (520~529)
3,9,9,1,1		,1,1,11,11,12,   //13 (530~539)
1,1,1,3,2		,1,1,1,7,1,      //14 (540~549)
1,1,4,6,3		,1,1,1,1,1,      //15 (550~559)
1,1,1,7,11		,11,1,1,1,11,    //16 (560~569)
11,1,3,9,4		,1,1,6,1,1,      //17 (570~579)
1,5,3,3,8		,1,5,1,9,1,      //18 (580~589)
11,8,6,6,11		,12,2,2,2,2,     //19 (590~599)
5,2,1,1,1		,3,8,8,8,9,      //20 (600~609)
8,1,1,1,1		,1,8,8,8,3,      //21 (610~619)
11,11,11
};

stock C_GetTipoCar(modeloid){
	if(modeloid >= 400 && modeloid <= 612) return C_TypeCarr[modeloid-400];
	else return -1;
}

stock C_GetAvailableSeat(vehicleid, start = 1){//nativa: GetAvailableSeat(400,0)
	new seats = C_GetVehicleMaxSeats(vehicleid);
	for (new i = start; i < seats; i ++) if (!C_IsVehicleSeatUsed(vehicleid, i)) return i;
	return -1;
}
stock C_GetVehicleMaxSeats(vehicleid){
    static const g_arrMaxSeats[] = {
		4, 2, 2, 2, 4, 4, 1, 2, 2, 4, 2, 2, 2, 4, 2, 2, 4, 2, 4, 2, 4, 4, 2, 2, 2, 1, 4, 4, 4, 2,
		1, 7, 1, 2, 2, 0, 2, 7, 4, 2, 4, 1, 2, 2, 2, 4, 1, 2, 1, 0, 0, 2, 1, 1, 1, 2, 2, 2, 4, 4,
		2, 2, 2, 2, 1, 1, 4, 4, 2, 2, 4, 2, 1, 1, 2, 2, 1, 2, 2, 4, 2, 1, 4, 3, 1, 1, 1, 4, 2, 2,
		4, 2, 4, 1, 2, 2, 2, 4, 4, 2, 2, 1, 2, 2, 2, 2, 2, 4, 2, 1, 1, 2, 1, 1, 2, 2, 4, 2, 2, 1,
		1, 2, 2, 2, 2, 2, 2, 2, 2, 4, 1, 1, 1, 2, 2, 2, 2, 7, 7, 1, 4, 2, 2, 2, 2, 2, 4, 4, 2, 2,
		4, 4, 2, 1, 2, 2, 2, 2, 2, 2, 4, 4, 2, 2, 1, 2, 4, 4, 1, 0, 0, 1, 1, 2, 1, 2, 2, 1, 2, 4,
		4, 2, 4, 1, 0, 4, 2, 2, 2, 2, 0, 0, 7, 2, 2, 1, 4, 4, 4, 2, 2, 2, 2, 2, 4, 2, 0, 0, 0, 4,
		0, 0
	};
	new model = GetVehicleModel(vehicleid);
	if (model >= 400 && model <= 611) return g_arrMaxSeats[model - 400];
	return 0;
}
stock C_IsVehicleSeatUsed(vehicleid, seat){
	for(new i=0; i<MAX_PLAYERS; i++)	if(IsPlayerConnected(i))
			if (IsPlayerInVehicle(i, vehicleid) && GetPlayerVehicleSeat(i) == seat) return 1;
	return 0;
}
