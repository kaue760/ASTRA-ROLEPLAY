/* Discord Connector
 * Version v0.3.5
 * made by maddinat0r
 */


#if defined dcconnector_included
	#endinput
#endif
#define dcconnector_included



enum DCC_ChannelType
{
	GUILD_TEXT = 0,
	DM = 1,
	GUILD_VOICE = 2,
	GROUP_DM = 3,
	GUILD_CATEGORY = 4
};

enum DCC_UserPresenceStatus
{
	INVALID = 0,
	ONLINE = 1,
	IDLE = 2,
	DO_NOT_DISTURB = 3,
	OFFLINE = 4
};

enum DCC_BotPresenceStatus
{
	INVALID = 0,
	ONLINE,
	IDLE,
	DO_NOT_DISTURB,
	INVISIBLE,
	OFFLINE
};

enum DCC_MessageReactionType
{
	REACTION_ADD = 0, // Sent when a user adds a reaction to a message.
	REACTION_REMOVE, // Sent when a user removes a reaction from a message.
	REACTION_REMOVE_ALL, // Sent when a user explicitly removes all reactions from a message.
	REACTION_REMOVE_EMOJI // Sent when a bot removes all instances of a given emoji from the reactions of a message.
};

#define DCC_INVALID_CHANNEL DCC_Channel:0
#define DCC_INVALID_USER DCC_User:0
#define DCC_INVALID_ROLE DCC_Role:0
#define DCC_INVALID_GUILD DCC_Guild:0

#define DCC_ID_SIZE (20 + 1)
#define DCC_USERNAME_SIZE (32 + 1)
#define DCC_NICKNAME_SIZE (32 + 1)
#define DCC_EMOJI_NAME_SIZE (32 + 1)
// natives

//  channels
stock DCC_Channel:DCC_FindChannelByName(const channel_name[]) { return 0; }
stock DCC_Channel:DCC_FindChannelById(const channel_id[]) { return 0; }

stock DCC_GetChannelId(DCC_Channel:channel, dest[DCC_ID_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetChannelType(DCC_Channel:channel, &DCC_ChannelType:type) { return 0; }
stock DCC_GetChannelGuild(DCC_Channel:channel, &DCC_Guild:guild) { return 0; }
stock DCC_GetChannelName(DCC_Channel:channel, dest[], max_size = sizeof dest) { return 0; }
stock DCC_GetChannelTopic(DCC_Channel:channel, dest[], max_size = sizeof dest) { return 0; }
stock DCC_GetChannelPosition(DCC_Channel:channel, &position) { return 0; }
stock DCC_IsChannelNsfw(DCC_Channel:channel, &bool:is_nsfw) { return 0; }
stock DCC_GetChannelParentCategory(DCC_Channel:channel, &DCC_Channel:category) { return 0; }

stock DCC_SendChannelMessage(DCC_Channel:channel, const message[], const callback[] = "", const format[] = "", {Float, _}:...) { return 0; }
stock DCC_SetChannelName(DCC_Channel:channel, const name[]) { return 0; }
stock DCC_SetChannelTopic(DCC_Channel:channel, const topic[]) { return 0; }
stock DCC_SetChannelPosition(DCC_Channel:channel, position) { return 0; }
stock DCC_SetChannelNsfw(DCC_Channel:channel, bool:is_nsfw) { return 0; }
stock DCC_SetChannelParentCategory(DCC_Channel:channel, DCC_Channel:parent_category) { return 0; }
stock DCC_DeleteChannel(DCC_Channel:channel) { return 0; }


// messages
stock DCC_GetMessageId(DCC_Message:message, dest[DCC_ID_SIZE], max_size = DCC_ID_SIZE) { return 0; }
stock DCC_GetMessageChannel(DCC_Message:message, &DCC_Channel:channel) { return 0; }
stock DCC_GetMessageAuthor(DCC_Message:message, &DCC_User:author) { return 0; }
stock DCC_GetMessageContent(DCC_Message:message, dest[], max_size = sizeof dest) { return 0; }
stock DCC_IsMessageTts(DCC_Message:message, &bool:is_tts) { return 0; }
stock DCC_IsMessageMentioningEveryone(DCC_Message:message, &bool:mentions_everyone) { return 0; }
stock DCC_GetMessageUserMentionCount(DCC_Message:message, &mentioned_user_count) { return 0; }
stock DCC_GetMessageUserMention(DCC_Message:message, offset, &DCC_User:mentioned_user) { return 0; }
stock DCC_GetMessageRoleMentionCount(DCC_Message:message, &mentioned_role_count) { return 0; }
stock DCC_GetMessageRoleMention(DCC_Message:message, offset, &DCC_Role:mentioned_role) { return 0; }

stock DCC_DeleteMessage(DCC_Message:message) { return 0; }

stock DCC_Message:DCC_GetCreatedMessage() { return 0; }

stock DCC_DeleteInternalMessage(DCC_Message:message) { return 0; }

stock DCC_EditMessage(DCC_Message:message, const content[], DCC_Embed:embed = DCC_Embed:0) { return 0; }

stock DCC_SetMessagePersistent(DCC_Message:message, bool:persistent) { return 0; }
stock DCC_CacheChannelMessage(const channel_id[DCC_ID_SIZE], const message_id[DCC_ID_SIZE], const callback[] = "", const format[] = "", {Float, _}:...) { return 0; }
//  users
stock DCC_User:DCC_FindUserByName(const user_name[], const user_discriminator[]) { return 0; }
stock DCC_User:DCC_FindUserById(const user_id[]) { return 0; }

stock DCC_GetUserName(DCC_User:user, dest[DCC_USERNAME_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetUserId(DCC_User:user, dest[DCC_ID_SIZE], max_size = DCC_ID_SIZE) { return 0; }
stock DCC_GetUserDiscriminator(DCC_User:user, dest[], max_size = sizeof dest) { return 0; }
stock DCC_IsUserBot(DCC_User:user, &bool:is_bot) { return 0; }
stock DCC_IsUserVerified(DCC_User:user, &bool:is_verified) { return 0; }


//  roles
stock DCC_Role:DCC_FindRoleByName(DCC_Guild:guild, const role_name[]) { return 0; }
stock DCC_Role:DCC_FindRoleById(const role_id[]) { return 0; }

stock DCC_GetRoleId(DCC_Role:role, dest[DCC_ID_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetRoleName(DCC_Role:role, dest[], max_size = sizeof dest) { return 0; }
stock DCC_GetRoleColor(DCC_Role:role, &color) { return 0; }
stock DCC_GetRoleColour(DCC_Role:role, &colour) { return 0; }
stock DCC_GetRolePermissions(DCC_Role:role, &perm_high, &perm_low) { return 0; }
stock DCC_IsRoleHoist(DCC_Role:role, &bool:is_hoist) { return 0; }
stock DCC_GetRolePosition(DCC_Role:role, &position) { return 0; }
stock DCC_IsRoleMentionable(DCC_Role:role, &bool:is_mentionable) { return 0; }


//  guilds
stock DCC_Guild:DCC_FindGuildByName(const guild_name[]) { return 0; }
stock DCC_Guild:DCC_FindGuildById(const guild_id[]) { return 0; }

stock DCC_GetGuildId(DCC_Guild:guild, dest[DCC_ID_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetGuildName(DCC_Guild:guild, dest[], max_size = sizeof dest) { return 0; }
stock DCC_GetGuildOwnerId(DCC_Guild:guild, dest[DCC_ID_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetGuildRole(DCC_Guild:guild, offset, &DCC_Role:role) { return 0; }
stock DCC_GetGuildRoleCount(DCC_Guild:guild, &count) { return 0; }
stock DCC_GetGuildMember(DCC_Guild:guild, offset, &DCC_User:user) { return 0; }
stock DCC_GetGuildMemberCount(DCC_Guild:guild, &count) { return 0; }
stock DCC_GetGuildMemberVoiceChannel(DCC_Guild:guild, DCC_User:user, &DCC_Channel:channel) { return 0; }
stock DCC_GetGuildMemberNickname(DCC_Guild:guild, DCC_User:user, dest[DCC_NICKNAME_SIZE], max_size = sizeof dest) { return 0; }
stock DCC_GetGuildMemberRole(DCC_Guild:guild, DCC_User:user, offset, &DCC_Role:role) { return 0; }
stock DCC_GetGuildMemberRoleCount(DCC_Guild:guild, DCC_User:user, &count) { return 0; }
stock DCC_HasGuildMemberRole(DCC_Guild:guild, DCC_User:user, DCC_Role:role, &bool:has_role) { return 0; }
stock DCC_GetGuildMemberStatus(DCC_Guild:guild, DCC_User:user, &DCC_UserPresenceStatus:status) { return 0; }
stock DCC_GetGuildChannel(DCC_Guild:guild, offset, &DCC_Channel:channel) { return 0; }
stock DCC_GetGuildChannelCount(DCC_Guild:guild, &count) { return 0; }
stock DCC_GetAllGuilds(DCC_Guild:dest[], max_size = sizeof dest) { return 0; }

stock DCC_SetGuildName(DCC_Guild:guild, const name[]) { return 0; }
stock DCC_CreateGuildChannel(DCC_Guild:guild, const name[], DCC_ChannelType:type, const callback[] = "", const format[] = "", {Float, _}:...) { return 0; }
stock DCC_Channel:DCC_GetCreatedGuildChannel() { return 0; }
stock DCC_SetGuildMemberNickname(DCC_Guild:guild, DCC_User:user, const nickname[]) { return 0; }
stock DCC_SetGuildMemberVoiceChannel(DCC_Guild:guild, DCC_User:user, DCC_Channel:channel) { return 0; }
stock DCC_AddGuildMemberRole(DCC_Guild:guild, DCC_User:user, DCC_Role:role) { return 0; }
stock DCC_RemoveGuildMemberRole(DCC_Guild:guild, DCC_User:user, DCC_Role:role) { return 0; }
stock DCC_RemoveGuildMember(DCC_Guild:guild, DCC_User:user) { return 0; }
stock DCC_CreateGuildMemberBan(DCC_Guild:guild, DCC_User:user, const reason[] = "") { return 0; }
stock DCC_RemoveGuildMemberBan(DCC_Guild:guild, DCC_User:user) { return 0; }
stock DCC_SetGuildRolePosition(DCC_Guild:guild, DCC_Role:role, position) { return 0; }
stock DCC_SetGuildRoleName(DCC_Guild:guild, DCC_Role:role, const name[]) { return 0; }
stock DCC_SetGuildRolePermissions(DCC_Guild:guild, DCC_Role:role, perm_high, perm_low) { return 0; }
stock DCC_SetGuildRoleColor(DCC_Guild:guild, DCC_Role:role, color) { return 0; }
stock DCC_SetGuildRoleHoist(DCC_Guild:guild, DCC_Role:role, bool:hoist) { return 0; }
stock DCC_SetGuildRoleMentionable(DCC_Guild:guild, DCC_Role:role, bool:mentionable) { return 0; }
stock DCC_CreateGuildRole(DCC_Guild:guild, const name[], const callback[] = "", const format[] = "", {Float, _}:...) { return 0; }
stock DCC_Role:DCC_GetCreatedGuildRole() { return 0; }
stock DCC_DeleteGuildRole(DCC_Guild:guild, DCC_Role:role) { return 0; }

// bot
stock DCC_BotPresenceStatus:DCC_GetBotPresenceStatus() { return 0; }

stock DCC_TriggerBotTypingIndicator(DCC_Channel:channel) { return 0; }
stock DCC_SetBotNickname(DCC_Guild:guild, const nickname[]) { return 0; }
stock DCC_ClearBotNickname(DCC_Guild:guild)
{
	return DCC_SetBotNickname(guild, "");
}
stock DCC_CreatePrivateChannel(DCC_User:user, const callback[], const format[] = "", {Float, _}:...) { return 0; }
stock DCC_Channel:DCC_GetCreatedPrivateChannel() { return 0; }
stock DCC_SetBotPresenceStatus(DCC_BotPresenceStatus:status) { return 0; }
stock DCC_SetBotActivity(const name[]) { return 0; }
stock DCC_ClearBotActivity()
{
	return DCC_SetBotActivity("");
}


// misc
stock DCC_EscapeMarkdown(const src[], dest[], max_size = sizeof dest) { return 0; }

// embedded messages
stock DCC_Embed:DCC_CreateEmbed(const title[] = "", const description[] = "", const url[] = "", const timestamp[] = "", color = 0, const footer_text[] = "", const footer_icon_url[] = "", const thumbnail_url[] = "", const image_url[] = "") { return 0; }
stock DCC_DeleteEmbed(DCC_Embed:embed) { return 0; }
stock DCC_SendChannelEmbedMessage(DCC_Channel:channel, DCC_Embed:embed, const message[] = "", const callback[] = "", const format[] = "", {Float, _}:...) { return 0; }
stock DCC_AddEmbedField(DCC_Embed:embed, const name[], const value[], bool:inline = false) { return 0; }
stock DCC_SetEmbedTitle(DCC_Embed:embed, const title[]) { return 0; }
stock DCC_SetEmbedDescription(DCC_Embed:embed, const description[]) { return 0; }
stock DCC_SetEmbedUrl(DCC_Embed:embed, const url[]) { return 0; }
stock DCC_SetEmbedTimestamp(DCC_Embed:embed, const timestamp[]) { return 0; }
stock DCC_SetEmbedColor(DCC_Embed:embed, color) { return 0; }
stock DCC_SetEmbedColour(DCC_Embed:embed, colour) { return 0; }
stock DCC_SetEmbedFooter(DCC_Embed:embed, const footer_text[], const footer_icon_url[] = "") { return 0; }
stock DCC_SetEmbedThumbnail(DCC_Embed:embed, const thumbnail_url[]) { return 0; }
stock DCC_SetEmbedImage(DCC_Embed:embed, const image_url[]) { return 0; }

// emoji
stock DCC_Emoji:DCC_CreateEmoji(const name[DCC_EMOJI_NAME_SIZE], const snowflake[DCC_ID_SIZE] = "") { return 0; }
stock DCC_DeleteEmoji(DCC_Emoji:emoji) { return 0; }
stock DCC_GetEmojiName(DCC_Emoji:emoji, dest[DCC_EMOJI_NAME_SIZE], maxlen = DCC_EMOJI_NAME_SIZE) { return 0; }

// reaction
stock DCC_CreateReaction(DCC_Message:message, DCC_Emoji:reaction_emoji) { return 0; }
stock DCC_DeleteMessageReaction(DCC_Message:message, DCC_Emoji:reaction_emoji = DCC_Emoji:0) { return 0; }

// callbacks
//  channels
forward DCC_OnChannelCreate(DCC_Channel:channel);
forward DCC_OnChannelUpdate(DCC_Channel:channel);
forward DCC_OnChannelDelete(DCC_Channel:channel);

// messages
forward DCC_OnMessageCreate(DCC_Message:message);
forward DCC_OnMessageDelete(DCC_Message:message);
forward DCC_OnMessageReaction(DCC_Message:message, DCC_User:reaction_user, DCC_Emoji:emoji, DCC_MessageReactionType:reaction_type);

//  users
forward DCC_OnUserUpdate(DCC_User:user);

//  guilds
forward DCC_OnGuildCreate(DCC_Guild:guild);
forward DCC_OnGuildUpdate(DCC_Guild:guild);
forward DCC_OnGuildDelete(DCC_Guild:guild);

forward DCC_OnGuildMemberAdd(DCC_Guild:guild, DCC_User:user);
forward DCC_OnGuildMemberUpdate(DCC_Guild:guild, DCC_User:user);
forward DCC_OnGuildMemberVoiceUpdate(DCC_Guild:guild, DCC_User:user, DCC_Channel:channel);
forward DCC_OnGuildMemberRemove(DCC_Guild:guild, DCC_User:user);

forward DCC_OnGuildRoleCreate(DCC_Guild:guild, DCC_Role:role);
forward DCC_OnGuildRoleUpdate(DCC_Guild:guild, DCC_Role:role);
forward DCC_OnGuildRoleDelete(DCC_Guild:guild, DCC_Role:role);
