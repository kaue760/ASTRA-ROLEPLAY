#include <Anti-Cheat/GunCheats>//Anti gun cheats -Rogue
#include <Anti-Cheat/LaggersDetect>//Lag spike\desnyc detector- Rogue
#include <Anti-Cheat/Opba>//Anti airbreak\teleport - Rogue
#include <Anti-Cheat/CarTroll>//Anti car trolls - Rogue
#include <Anti-Cheat/Jetpack>//Anti jetpack cheats- Rogue
#include <Anti-Cheat/VehicleAbuse>//Anti carswing\particlespam - Lorenc_
#include <Anti-Cheat/MoneyCheats>//Anti money cheats- Rogue
#include <Anti-Cheat/GodMode>//Anti godmode -Rogue
#include <Anti-Cheat/BugCheats>//Depresses 5 abusing bugs triggered by cheats. -Rogue
#include <Anti-Cheat/FakeKill> //Anti fake kill -Rogue
#include <Anti-Cheat/FakeConnect>//Anti fake clients - Rogue
#include <Anti-Cheat/SpeedCheats>//Anti speed cheats- Rogue
#include <Anti-Cheat/VehicleMods>//Anti illegal car mods -Emmet_
#include <Anti-Cheat/CarSpam>//Anti car spam - Rogue
#include <Anti-Cheat/EasyDialog> //Anti dialog spoof/crash- Emmet_ (easyDialog)
#include <Anti-Cheat/ChatSpam>//Anti chat spam- Rogue
#include <Anti-Cheat/SlideBug>//Anti slide bug abuse- Rogue

#define VIOLATION_CODE_BUGATTEMPT 0
#define VIOLATION_CODE_LAGOUT 1
#define VIOLATION_CODE_SLIDEBUG 2
#define VIOLATION_CODE_INVALIDMODS 3
#define VIOLATION_CODE_PARTICLESPAM 4
#define VIOLATION_CODE_CARSWING 5
#define VIOLATION_CODE_MONEYHACK 6
#define VIOLATION_CODE_CARTROLL 7
#define VIOLATION_CODE_CARSPAM 8
#define VIOLATION_CODE_AIRBRAKE 9
#define VIOLATION_CODE_SPEEDING 10
#define VIOLATION_CODE_CHATSPAM 11
#define VIOLATION_CODE_JETPACK 12
#define VIOLATION_CODE_FAKECONNECT 13
#define VIOLATION_CODE_FAKEKILL 14
#define VIOLATION_CODE_GODMODE 15
#define VIOLATION_CODE_WEPHACKS 16


public OnPlayerFakeKill(playerid, spoofedid, spoofedreason, faketype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_FAKEKILL);
	return 1;
}

public OnPlayerFakeConnect(playerid)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_FAKECONNECT);
	return 1;
}

public OnPlayerJetpackCheat(playerid)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_JETPACK);
	return 1;
}

public OnPlayerGodmode(playerid, gmtype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_GODMODE);
	return 1;
}

public OnPlayerSpamChat(playerid)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_CHATSPAM);
	return 1;
}

public OnPlayerGunCheat(playerid, weaponid, ammo, hacktype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_WEPHACKS);
	return 1;
}

public OnPlayerSpeedCheat(playerid, speedtype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_SPEEDING);
	return 1;
}

public OnPlayerBreakAir(playerid, breaktype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_AIRBRAKE);
	return 1;
}

public OnPlayerSpamCars(playerid, number)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_CARSPAM);
	return 1;
}

public OnPlayerCarTroll(playerid, vehicleid, trolledid, trolltype)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_CARTROLL);
	return 1;
}

public OnPlayerCashCheat(playerid, oldcash, newcash, amount)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_MONEYHACK);
	return 1;
}

public OnPlayerCarSwing(playerid, vehicleid)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_CARSWING);
	return 1;
}

public OnPlayerParticleSpam(playerid, vehicleid)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_PARTICLESPAM);
	return 1;
}

public OnVehicleModEx(playerid, vehicleid, componentid, illegal)
{
	if(illegal)
	{
		OnPlayerViolate(playerid,  VIOLATION_CODE_INVALIDMODS);
	}
	return 1;
}

public OnPlayerSlide(playerid, weaponid, speed)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_SLIDEBUG);
	return 1;
}

public OnPlayerLagout(playerid, lagtype, ping)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_LAGOUT);
	return 1;
}


public OnPlayerBugAttempt(playerid, bugcode)
{
	OnPlayerViolate(playerid,  VIOLATION_CODE_BUGATTEMPT);
	return 1;
}


forward OnPlayerViolate(playerid, xiter);
