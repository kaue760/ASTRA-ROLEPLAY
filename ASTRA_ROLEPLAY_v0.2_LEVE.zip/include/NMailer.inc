#include <a_http>

#if !defined Function
	#define Function::%0(%1)    %0(%1); public %0(%1)
#endif

#define Link "www.anything.com/envia.php?" //Download the PHP Script

Function::SendEmail(Email[],Assunto[],Remetente[],Mensagem[])
{
    if(strfind(Email, "@", true)) return 0;
    new Link[1200];
    format(Link,sizeof(Link),"%s?Email=%s&Assunto=%s&From=%s&Mensagem=%s", Link, Email,Assunto,Remetente,Mensagem);
    for(new c; c < strlen(Link)+1; c++)
    {
         if(Link[c] == ' ') Link[c] = '+';
    }
    HTTP(0, HTTP_POST, Link, "", "");
    return 1;
}